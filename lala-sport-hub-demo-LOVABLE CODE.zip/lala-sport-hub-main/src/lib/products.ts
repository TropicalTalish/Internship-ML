import batImg from "@/assets/product-bat.jpg";
import ballImg from "@/assets/product-ball.jpg";
import footballImg from "@/assets/product-football.jpg";
import shoesImg from "@/assets/product-shoes.jpg";
import volleyballImg from "@/assets/product-volleyball.jpg";
import badmintonImg from "@/assets/product-badminton.jpg";
import fitnessImg from "@/assets/product-fitness.jpg";
import padsImg from "@/assets/product-pads.jpg";
import glovesImg from "@/assets/product-gloves.jpg";
import jerseyCricket from "@/assets/jersey-cricket.jpg";
import jerseyFootball from "@/assets/jersey-football.jpg";
import jerseyVolleyball from "@/assets/jersey-volleyball.jpg";

export type SportSlug =
  | "cricket"
  | "football"
  | "volleyball-badminton"
  | "fitness"
  | "shoes"
  | "custom-jerseys";

export interface Sport {
  slug: SportSlug;
  name: string;
  tagline: string;
  description: string;
  eyebrow: string;
}

export const SPORTS: Sport[] = [
  {
    slug: "cricket",
    name: "Cricket",
    eyebrow: "01 / Heritage Discipline",
    tagline: "Willow, leather, precision.",
    description:
      "English & Kashmir Willow bats, match-grade leather balls, protective gear and kit bags — the full complement for every level of play.",
  },
  {
    slug: "football",
    name: "Football",
    eyebrow: "02 / The Global Game",
    tagline: "Ball, boot, and everything between.",
    description:
      "Match and training balls, moulded and studded boots, shin guards and training aids for pitch-ready performance.",
  },
  {
    slug: "volleyball-badminton",
    name: "Volleyball & Badminton",
    eyebrow: "03 / Court Sports",
    tagline: "For the indoor arena.",
    description:
      "Match-quality volleyballs and badminton racquets, shuttlecocks, and tournament nets built for clubs and academies.",
  },
  {
    slug: "fitness",
    name: "Fitness & Training",
    eyebrow: "04 / Preparation",
    tagline: "The work that comes before.",
    description:
      "Agility ladders, cones, resistance bands and gym accessories — the tools for the training block.",
  },
  {
    slug: "shoes",
    name: "Sports Shoes",
    eyebrow: "05 / Footwear",
    tagline: "Grip, cushion, propulsion.",
    description:
      "Running, court and cross-training silhouettes engineered for the way each sport moves.",
  },
  {
    slug: "custom-jerseys",
    name: "Custom Jerseys",
    eyebrow: "The Specialty",
    tagline: "Made to order in Kamra.",
    description:
      "Bespoke team kits for cricket, football and volleyball. Your colours, your crest, your names and numbers.",
  },
];

export interface Product {
  id: string;
  name: string;
  category: Exclude<SportSlug, "custom-jerseys">;
  price: number; // PKR
  image: string;
  alt: string;
  tagline: string;
  description: string;
  specs: { label: string; value: string }[];
  featured?: boolean;
  new?: boolean;
  stock: "in-stock" | "low-stock";
}

export const PRODUCTS: Product[] = [
  // ---------- CRICKET ----------
  {
    id: "striker-grade-1-willow",
    name: "Striker Grade 1 English Willow",
    category: "cricket",
    price: 45000,
    image: batImg,
    alt: "Premium Grade 1 English Willow cricket bat with black grip, studio-lit on bone background.",
    tagline: "Our flagship blade.",
    description:
      "Hand-picked Grade 1 English Willow with tight, straight grain and a naturally pressed sweet spot low on the blade. Balanced for the modern stroke-maker.",
    specs: [
      { label: "Willow", value: "Grade 1 English" },
      { label: "Weight", value: "1180–1220g" },
      { label: "Sweet spot", value: "Mid-to-low" },
      { label: "Handle", value: "Traditional cane, oval" },
    ],
    featured: true,
    stock: "in-stock",
  },
  {
    id: "atlas-kashmir-willow",
    name: "Atlas Kashmir Willow",
    category: "cricket",
    price: 8500,
    image: batImg,
    alt: "Kashmir Willow cricket bat on warm bone background.",
    tagline: "The everyday performer.",
    description:
      "A robust Kashmir Willow blade built for club, tape-ball and academy use. Balanced pickup, resilient face.",
    specs: [
      { label: "Willow", value: "Kashmir" },
      { label: "Weight", value: "1200–1260g" },
      { label: "Sweet spot", value: "Mid" },
    ],
    stock: "in-stock",
  },
  {
    id: "test-grade-leather-ball",
    name: "Test Grade Leather Ball",
    category: "cricket",
    price: 2400,
    image: ballImg,
    alt: "Red four-piece leather cricket ball with pronounced hand-stitched seam.",
    tagline: "Four-piece, hand-stitched.",
    description:
      "Full-grain alum-tanned leather, four-piece construction, prominent seam. Retains shape and shine over long spells.",
    specs: [
      { label: "Construction", value: "Four-piece" },
      { label: "Weight", value: "156g" },
      { label: "Use", value: "Match / red-ball" },
    ],
    featured: true,
    stock: "in-stock",
  },
  {
    id: "training-tape-ball",
    name: "Weighted Tape Ball (Box of 6)",
    category: "cricket",
    price: 900,
    image: ballImg,
    alt: "Boxed set of tape-ball cricket balls.",
    tagline: "Streetplay, refined.",
    description:
      "The Pakistan classic — weighted tennis-ball core, hand-taped seam. Six per box.",
    specs: [
      { label: "Quantity", value: "6 balls" },
      { label: "Use", value: "Tape-ball cricket" },
    ],
    stock: "in-stock",
  },
  {
    id: "vanguard-batting-pads",
    name: "Vanguard Batting Pads",
    category: "cricket",
    price: 6800,
    image: padsImg,
    alt: "Pair of bone and forest-green cricket batting pads standing upright.",
    tagline: "Lightweight protection.",
    description:
      "High-density foam bolsters over a moulded shell. Ventilated calf cradle, cane rods in the knee roll.",
    specs: [
      { label: "Weight", value: "≈ 950g / pair" },
      { label: "Sizes", value: "Youth, Mens" },
    ],
    featured: true,
    stock: "in-stock",
  },
  {
    id: "pro-batting-gloves",
    name: "Pro Series Batting Gloves",
    category: "cricket",
    price: 5200,
    image: glovesImg,
    alt: "Pair of white and forest-green premium cricket batting gloves.",
    tagline: "Sheep-leather palm.",
    description:
      "Split-finger design with segmented sausage protection, sheep-leather palm and moisture-wicking towelling cuff.",
    specs: [
      { label: "Palm", value: "Sheep leather" },
      { label: "Fit", value: "Right / Left hand" },
    ],
    stock: "in-stock",
  },
  {
    id: "carbon-shell-helmet",
    name: "Carbon-Shell Cricket Helmet",
    category: "cricket",
    price: 9800,
    image: padsImg,
    alt: "Cricket batting helmet with steel grille.",
    tagline: "ICC-spec grille.",
    description:
      "ABS-carbon composite shell with ICC-compliant fixed grille. Moisture-wicking suede lining.",
    specs: [
      { label: "Shell", value: "ABS composite" },
      { label: "Grille", value: "Titanium-look steel" },
    ],
    stock: "in-stock",
  },
  {
    id: "duffel-kit-bag",
    name: "Field Duffel Kit Bag",
    category: "cricket",
    price: 4200,
    image: padsImg,
    alt: "Cricket kit duffel bag.",
    tagline: "The full kit, one bag.",
    description:
      "Reinforced polyester exterior, padded bat sleeve, ventilated shoe compartment. Wheeled option available.",
    specs: [
      { label: "Capacity", value: "≈ 90L" },
      { label: "Bat sleeve", value: "Padded, external" },
    ],
    new: true,
    stock: "in-stock",
  },

  // ---------- FOOTBALL ----------
  {
    id: "meridian-match-ball",
    name: "Meridian Match Ball",
    category: "football",
    price: 3800,
    image: footballImg,
    alt: "Premium white and charcoal panelled match football on bone background.",
    tagline: "Thermally bonded.",
    description:
      "Thermally-bonded panels for a true, seamless flight. Latex bladder holds pressure over ninety.",
    specs: [
      { label: "Size", value: "5 (Adult)" },
      { label: "Construction", value: "Thermal-bonded" },
    ],
    featured: true,
    stock: "in-stock",
  },
  {
    id: "training-football-3pack",
    name: "Training Football (3-Pack)",
    category: "football",
    price: 5400,
    image: footballImg,
    alt: "Three training footballs stacked.",
    tagline: "For the drill session.",
    description:
      "Durable machine-stitched training balls, textured PU cover. Sold as a set of three.",
    specs: [{ label: "Quantity", value: "3 balls" }],
    stock: "in-stock",
  },
  {
    id: "aeroflex-boots",
    name: "Aeroflex FG Football Boots",
    category: "football",
    price: 8500,
    image: shoesImg,
    alt: "Firm-ground football boots in forest green and bone.",
    tagline: "Firm-ground stud pattern.",
    description:
      "Micro-fibre upper over an EVA midsole. Conical + bladed stud pattern for rotational quickness.",
    specs: [
      { label: "Surface", value: "Firm ground (FG)" },
      { label: "Sizes", value: "UK 6–11" },
    ],
    stock: "in-stock",
  },
  {
    id: "shin-guards",
    name: "Slip-in Shin Guards",
    category: "football",
    price: 1800,
    image: glovesImg,
    alt: "Pair of football shin guards.",
    tagline: "Contoured EVA back.",
    description:
      "Impact-resistant polypropylene face over contoured EVA. Ankle cuff included.",
    specs: [{ label: "Sizes", value: "S / M / L" }],
    stock: "in-stock",
  },

  // ---------- VOLLEYBALL & BADMINTON ----------
  {
    id: "hyperspike-volleyball",
    name: "HyperSpike Match Volleyball",
    category: "volleyball-badminton",
    price: 4500,
    image: volleyballImg,
    alt: "White and forest-green match volleyball on bone background.",
    tagline: "18-panel, soft-touch.",
    description:
      "Micro-fibre composite cover with cushioned sub-layer. FIVB-comparable weight and rebound.",
    specs: [
      { label: "Weight", value: "260–280g" },
      { label: "Circumference", value: "65–67cm" },
    ],
    featured: true,
    stock: "in-stock",
  },
  {
    id: "shuttlecock-tube-6",
    name: "Feather Shuttlecock (Tube of 6)",
    category: "volleyball-badminton",
    price: 1600,
    image: badmintonImg,
    alt: "Tube of six feather badminton shuttlecocks.",
    tagline: "Grade-A goose feather.",
    description:
      "Grade-A goose feather, calibrated for medium speed. Ships in a hard tube.",
    specs: [
      { label: "Quantity", value: "6 shuttles" },
      { label: "Speed", value: "77" },
    ],
    stock: "in-stock",
  },
  {
    id: "aero-badminton-racquet",
    name: "Aero Carbon Badminton Racquet",
    category: "volleyball-badminton",
    price: 5400,
    image: badmintonImg,
    alt: "Carbon-frame badminton racquet with matte navy finish.",
    tagline: "Head-light for defence.",
    description:
      "Carbon composite frame, head-light balance for quick net exchanges. Pre-strung at 22lb.",
    specs: [
      { label: "Frame", value: "Carbon composite" },
      { label: "Weight", value: "≈ 88g" },
    ],
    new: true,
    stock: "in-stock",
  },
  {
    id: "tournament-volleyball-net",
    name: "Tournament Volleyball Net",
    category: "volleyball-badminton",
    price: 6800,
    image: volleyballImg,
    alt: "Tournament-grade volleyball net folded.",
    tagline: "Kevlar top cable.",
    description:
      "Woven polyethylene mesh, kevlar-reinforced top cable, canvas headband. Regulation 9.5m.",
    specs: [
      { label: "Length", value: "9.5m" },
      { label: "Standard", value: "Regulation" },
    ],
    stock: "low-stock",
  },

  // ---------- FITNESS ----------
  {
    id: "agility-marker-set",
    name: "Agility Marker & Ladder Set",
    category: "fitness",
    price: 3200,
    image: fitnessImg,
    alt: "Training set including agility ladder, cones and resistance band.",
    tagline: "Footwork, on demand.",
    description:
      "Twelve-rung fabric agility ladder, ten collapsible cones and a mid-tension resistance band.",
    specs: [
      { label: "Ladder", value: "12 rungs, 4m" },
      { label: "Cones", value: "10 pcs, 15cm" },
    ],
    featured: true,
    stock: "in-stock",
  },
  {
    id: "resistance-band-set",
    name: "Resistance Band Set (5)",
    category: "fitness",
    price: 2200,
    image: fitnessImg,
    alt: "Set of five colour-coded resistance bands.",
    tagline: "Five tensions.",
    description:
      "Five colour-coded latex bands from 10lb to 50lb. Ships with door anchor and handles.",
    specs: [{ label: "Tensions", value: "10, 20, 30, 40, 50 lb" }],
    stock: "in-stock",
  },
  {
    id: "cones-24pack",
    name: "Training Cones (24-Pack)",
    category: "fitness",
    price: 1400,
    image: fitnessImg,
    alt: "Set of 24 collapsible orange training cones.",
    tagline: "Mark the drill.",
    description:
      "Twenty-four collapsible orange PVC cones. Nest into a mesh carry bag.",
    specs: [
      { label: "Quantity", value: "24 cones" },
      { label: "Height", value: "15 cm" },
    ],
    stock: "in-stock",
  },

  // ---------- SHOES ----------
  {
    id: "velocity-court-pro",
    name: "Velocity Court Pro",
    category: "shoes",
    price: 8200,
    image: shoesImg,
    alt: "Low-top court shoe in forest green, bone and burnt sienna.",
    tagline: "The all-court silhouette.",
    description:
      "Gum-rubber outsole for indoor grip, molded heel counter, breathable mesh vamp.",
    specs: [
      { label: "Surface", value: "Indoor court" },
      { label: "Drop", value: "8mm" },
    ],
    featured: true,
    stock: "in-stock",
  },
  {
    id: "distance-runner-01",
    name: "Distance Runner 01",
    category: "shoes",
    price: 9600,
    image: shoesImg,
    alt: "Modern distance running shoe in bone with green accents.",
    tagline: "For the long block.",
    description:
      "Rocker-plate midsole with high-rebound foam. Engineered mesh upper, seamless tongue.",
    specs: [
      { label: "Surface", value: "Road" },
      { label: "Drop", value: "6mm" },
    ],
    new: true,
    stock: "in-stock",
  },
  {
    id: "cross-trainer-lo",
    name: "Cross-Trainer Lo",
    category: "shoes",
    price: 7200,
    image: shoesImg,
    alt: "Low-cut cross-training shoe.",
    tagline: "Gym-to-field.",
    description:
      "Flat, stable base for lifting; grippy outsole for turf work. Reinforced medial cage.",
    specs: [
      { label: "Surface", value: "Gym / turf" },
      { label: "Drop", value: "4mm" },
    ],
    stock: "in-stock",
  },
];

// Jersey design gallery — showcased on the Custom Jerseys page.
export interface JerseyDesign {
  id: string;
  name: string;
  sport: "Cricket" | "Football" | "Volleyball";
  image: string;
  alt: string;
  palette: string;
  detail: string;
}

export const JERSEY_DESIGNS: JerseyDesign[] = [
  {
    id: "khan-10-cricket",
    name: "Colour Kit — 'Khan / 10'",
    sport: "Cricket",
    image: jerseyCricket,
    alt: "Custom forest-green cricket jersey with burnt sienna shoulder panels, back showing player name Khan and number 10.",
    palette: "Forest × Sienna",
    detail:
      "Coloured limited-overs kit shown with player name and number applied by heat transfer. Custom crest embroidered at chest.",
  },
  {
    id: "ali-7-football",
    name: "Diagonal Sash — 'Ali / 7'",
    sport: "Football",
    image: jerseyFootball,
    alt: "Custom navy football jersey with a diagonal burnt sienna sash and player name Ali number 7 on the back.",
    palette: "Navy × Sienna",
    detail:
      "Sublimated mesh with a full-back diagonal sash. Name, number and crest fully custom.",
  },
  {
    id: "court-white-volleyball",
    name: "Court White — Team Kit",
    sport: "Volleyball",
    image: jerseyVolleyball,
    alt: "Custom bone-white volleyball jersey with forest green side panels and burnt sienna neckline trim.",
    palette: "Bone × Forest",
    detail:
      "Sleeveless V-neck cut in performance mesh. Crest, side panels and neckline trim tailored per club.",
  },
  {
    id: "test-whites-cricket",
    name: "Traditional Test Whites",
    sport: "Cricket",
    image: jerseyCricket,
    alt: "Traditional white test cricket kit with club colours on collar.",
    palette: "Bone × Forest",
    detail: "Long-form whites with tipped collar and cuff detailing to club colours.",
  },
  {
    id: "home-away-football",
    name: "Home / Away Bundle",
    sport: "Football",
    image: jerseyFootball,
    alt: "Home and away football kit pair.",
    palette: "Any two-colour",
    detail:
      "Paired home and away kits designed together for tonal continuity. Priced per set of 15.",
  },
  {
    id: "academy-cricket",
    name: "Academy Series",
    sport: "Cricket",
    image: jerseyCricket,
    alt: "Academy cricket kit with school crest.",
    palette: "Custom",
    detail:
      "Cost-effective sublimated poly kit designed for school and academy volume orders.",
  },
];

export function formatPKR(n: number): string {
  return "PKR " + n.toLocaleString("en-PK");
}

export const CONTACT = {
  phone: "0307-8936637",
  whatsappNumber: "923078936637",
  location: "Waisa, Kamra, KPK, Pakistan",
  facebook: "https://facebook.com/lalasports",
};

export function whatsappLink(message: string) {
  return `https://wa.me/${CONTACT.whatsappNumber}?text=${encodeURIComponent(message)}`;
}
