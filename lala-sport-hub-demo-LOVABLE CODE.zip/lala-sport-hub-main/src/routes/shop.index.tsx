import { createFileRoute, Link } from "@tanstack/react-router";
import { PRODUCTS, SPORTS, type SportSlug } from "@/lib/products";
import { ProductCard } from "@/components/site/ProductCard";

export const Route = createFileRoute("/shop/")({
  head: () => ({
    meta: [
      { title: "Shop — All Sports Equipment | Lala Sports" },
      {
        name: "description",
        content:
          "Browse the full Lala Sports catalogue — cricket, football, volleyball, badminton, fitness gear and sports shoes. WhatsApp ordering from Kamra, Pakistan.",
      },
      { property: "og:title", content: "Shop — All Sports Equipment | Lala Sports" },
      {
        property: "og:description",
        content:
          "Cricket, football, court sports, training and footwear — the full Lala Sports catalogue.",
      },
    ],
  }),
  component: ShopIndex,
});

function ShopIndex() {
  const cats = SPORTS.filter((s) => s.slug !== "custom-jerseys");
  return (
    <div className="bg-bone">
      <ShopHeader
        eyebrow="The Catalogue"
        title="Every discipline, one shop."
        subtitle={`${PRODUCTS.length} products across ${cats.length} categories — filter by sport below.`}
      />

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-6">
        <CategoryFilter active={null} />
      </section>

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 pb-24">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-14">
          {PRODUCTS.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>
    </div>
  );
}

export function ShopHeader({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <section className="border-b border-ink/10 bg-bone">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 pt-20 pb-14">
        <p className="eyebrow text-sienna mb-4">{eyebrow}</p>
        <h1 className="font-serif text-5xl md:text-7xl leading-[1] max-w-3xl">
          {title}
        </h1>
        {subtitle && (
          <p className="mt-6 text-ink/60 max-w-xl text-lg">{subtitle}</p>
        )}
      </div>
    </section>
  );
}

export function CategoryFilter({ active }: { active: SportSlug | null }) {
  const cats = SPORTS.filter((s) => s.slug !== "custom-jerseys");
  return (
    <div className="flex flex-wrap gap-2 items-center py-4 border-b border-ink/10">
      <span className="eyebrow text-ink/40 mr-3">Filter</span>
      <Link
        to="/shop"
        className={
          "px-4 py-2 text-xs font-medium uppercase tracking-widest border transition-colors " +
          (active === null
            ? "bg-forest text-bone border-forest"
            : "border-ink/15 hover:bg-ink hover:text-bone")
        }
      >
        All
      </Link>
      {cats.map((c) => (
        <Link
          key={c.slug}
          to="/shop/$category"
          params={{ category: c.slug }}
          className={
            "px-4 py-2 text-xs font-medium uppercase tracking-widest border transition-colors " +
            (active === c.slug
              ? "bg-forest text-bone border-forest"
              : "border-ink/15 hover:bg-ink hover:text-bone")
          }
        >
          {c.name}
        </Link>
      ))}
    </div>
  );
}
