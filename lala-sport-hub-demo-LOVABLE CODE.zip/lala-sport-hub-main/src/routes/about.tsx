import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — A sporting-goods house in Kamra | Lala Sports" },
      {
        name: "description",
        content:
          "Lala Sports is an independent sporting-goods house in Waisa, Kamra — supplying gear across every code and manufacturing custom team jerseys for clubs, schools and academies across Pakistan.",
      },
      { property: "og:title", content: "About | Lala Sports" },
      {
        property: "og:description",
        content:
          "A sporting-goods house from Waisa, Kamra — kit for every code, and custom kits made in-house.",
      },
    ],
  }),
  component: About,
});

function About() {
  return (
    <div className="bg-bone">
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 pt-24 pb-16 grid md:grid-cols-12 gap-10">
        <div className="md:col-span-8">
          <p className="eyebrow text-sienna mb-6">About the shop</p>
          <h1 className="font-serif text-6xl md:text-8xl leading-[0.95] text-balance">
            A sporting-goods house from <span className="italic">Waisa, Kamra</span>.
          </h1>
        </div>
        <div className="md:col-span-4 md:pt-10 text-ink/70 space-y-6 text-lg leading-relaxed">
          <p>
            Lala Sports began as a corner shop in Waisa — cricket bats stacked
            against the wall, footballs in the window, a tape-measure for
            school kits. It's grown, but the idea hasn't.
          </p>
          <p>
            Kit for every code, priced fairly, backed by people who actually
            play. And a workshop out back that stitches custom jerseys good
            enough for a first-XI.
          </p>
        </div>
      </section>

      <section className="border-y border-ink/10 bg-mist/30 py-20">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 grid md:grid-cols-3 gap-14">
          {[
            {
              n: "α",
              h: "The full range",
              p: "Cricket, football, volleyball, badminton, fitness, footwear. We stock what actual clubs and schools order — not just what's trendy on the feed.",
            },
            {
              n: "β",
              h: "Made, not just sold",
              p: "Custom jerseys are stitched in our own Kamra workshop. Fabric, cut, print, embroidery — start to finish, in-house, no middlemen.",
            },
            {
              n: "γ",
              h: "WhatsApp, always",
              p: "Every order runs through WhatsApp — no bots, no queues. You talk to the person who sends the shipment.",
            },
          ].map((c) => (
            <div key={c.h}>
              <p className="font-serif italic text-4xl text-sienna leading-none mb-4">
                {c.n}
              </p>
              <h2 className="font-serif text-2xl mb-3">{c.h}</h2>
              <p className="text-ink/60 leading-relaxed">{c.p}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24 grid md:grid-cols-2 gap-14 items-center">
        <div>
          <p className="eyebrow text-sienna mb-4">Where to find us</p>
          <h2 className="font-serif text-5xl md:text-6xl leading-[1]">
            Main Bazaar, Waisa — <span className="italic">walk in or call</span>.
          </h2>
          <p className="mt-6 text-ink/60 max-w-md leading-relaxed">
            The workshop is open six days a week for team fittings and crest
            proofs. For everyone else, WhatsApp is the fastest line in.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/contact"
              className="bg-forest text-bone px-8 py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-ink transition-colors"
            >
              Contact us
            </Link>
            <Link
              to="/custom-jerseys"
              className="border border-ink/20 px-8 py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-ink hover:text-bone transition-colors"
            >
              Start a custom order
            </Link>
          </div>
        </div>
        <div className="border border-ink/15 p-10 bg-bone">
          <dl className="space-y-6 text-sm">
            {[
              ["Location", "Waisa, Kamra, KPK, Pakistan"],
              ["Phone", "0307-8936637"],
              ["Hours", "Mon–Sat · 10:00 – 20:00 PKT"],
              ["Established", "Kamra"],
              ["Ships", "Nationwide across Pakistan"],
            ].map(([k, v]) => (
              <div
                key={k}
                className="grid grid-cols-3 gap-4 border-b border-ink/10 pb-6 last:border-0 last:pb-0"
              >
                <dt className="eyebrow text-ink/50">{k}</dt>
                <dd className="col-span-2 text-ink/80">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>
    </div>
  );
}
