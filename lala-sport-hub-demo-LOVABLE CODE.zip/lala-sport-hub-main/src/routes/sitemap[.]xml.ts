import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";

const BASE_URL = "";

interface SitemapEntry {
  path: string;
  changefreq?: "weekly" | "monthly";
  priority?: string;
}

const STATIC: SitemapEntry[] = [
  { path: "/", changefreq: "weekly", priority: "1.0" },
  { path: "/shop", changefreq: "weekly", priority: "0.9" },
  { path: "/shop/cricket", changefreq: "weekly", priority: "0.8" },
  { path: "/shop/football", changefreq: "weekly", priority: "0.8" },
  { path: "/shop/volleyball-badminton", changefreq: "weekly", priority: "0.8" },
  { path: "/shop/fitness", changefreq: "weekly", priority: "0.8" },
  { path: "/shop/shoes", changefreq: "weekly", priority: "0.8" },
  { path: "/custom-jerseys", changefreq: "weekly", priority: "1.0" },
  { path: "/about", changefreq: "monthly", priority: "0.5" },
  { path: "/contact", changefreq: "monthly", priority: "0.5" },
  { path: "/faq", changefreq: "monthly", priority: "0.4" },
];

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const { PRODUCTS } = await import("@/lib/products");
        const productEntries: SitemapEntry[] = PRODUCTS.map((p) => ({
          path: `/product/${p.id}`,
          changefreq: "weekly",
          priority: "0.7",
        }));
        const all = [...STATIC, ...productEntries];

        const urls = all.map((e) =>
          [
            `  <url>`,
            `    <loc>${BASE_URL}${e.path}</loc>`,
            e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
            e.priority ? `    <priority>${e.priority}</priority>` : null,
            `  </url>`,
          ]
            .filter(Boolean)
            .join("\n"),
        );

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
