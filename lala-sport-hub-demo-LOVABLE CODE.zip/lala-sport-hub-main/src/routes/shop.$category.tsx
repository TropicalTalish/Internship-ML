import { createFileRoute, notFound } from "@tanstack/react-router";
import { PRODUCTS, SPORTS, type SportSlug } from "@/lib/products";
import { ProductCard } from "@/components/site/ProductCard";
import { CategoryFilter, ShopHeader } from "./shop.index";

const VALID: SportSlug[] = [
  "cricket",
  "football",
  "volleyball-badminton",
  "fitness",
  "shoes",
];

export const Route = createFileRoute("/shop/$category")({
  beforeLoad: ({ params }) => {
    if (!VALID.includes(params.category as SportSlug)) throw notFound();
  },
  head: ({ params }) => {
    const sport = SPORTS.find((s) => s.slug === params.category);
    const name = sport?.name ?? "Shop";
    return {
      meta: [
        { title: `${name} — Shop | Lala Sports` },
        {
          name: "description",
          content: sport
            ? `${sport.description} Shop ${name.toLowerCase()} at Lala Sports, Kamra.`
            : "Shop premium sports equipment at Lala Sports.",
        },
        { property: "og:title", content: `${name} — Shop | Lala Sports` },
        {
          property: "og:description",
          content: sport?.description ?? "Premium sports equipment.",
        },
      ],
    };
  },
  component: CategoryPage,
  notFoundComponent: () => (
    <div className="p-24 text-center">Category not found.</div>
  ),
  errorComponent: ({ error }) => (
    <div className="p-24 text-center text-sm text-ink/60">
      Couldn't load this category. {error.message}
    </div>
  ),
});

function CategoryPage() {
  const { category } = Route.useParams();
  const sport = SPORTS.find((s) => s.slug === category)!;
  const items = PRODUCTS.filter((p) => p.category === category);

  return (
    <div className="bg-bone">
      <ShopHeader
        eyebrow={sport.eyebrow}
        title={sport.tagline}
        subtitle={sport.description}
      />

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <CategoryFilter active={category as SportSlug} />
      </section>

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-16">
        {items.length === 0 ? (
          <p className="py-24 text-center text-ink/50">
            No products in this category yet — check back soon, or WhatsApp us
            for a bespoke enquiry.
          </p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-14">
            {items.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
