import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { JERSEY_DESIGNS, whatsappLink } from "@/lib/products";

export const Route = createFileRoute("/custom-jerseys")({
  head: () => ({
    meta: [
      { title: "Custom Team Jerseys — Made in Kamra | Lala Sports" },
      {
        name: "description",
        content:
          "Bespoke team jerseys manufactured in Kamra, Pakistan. Cricket, football and volleyball kits with your crest, colours, player names and numbers. Team, school and academy orders.",
      },
      {
        property: "og:title",
        content: "Custom Team Jerseys — Made in Kamra | Lala Sports",
      },
      {
        property: "og:description",
        content:
          "Team kits made to order — your crest, your colours, your names and numbers.",
      },
      { property: "og:image", content: JERSEY_DESIGNS[0].image },
      { name: "twitter:image", content: JERSEY_DESIGNS[0].image },
    ],
  }),
  component: CustomJerseys,
});

const STEPS = [
  {
    n: "01",
    title: "Select your kit",
    body: "Pick the sport, silhouette and fabric grade. Cricket colour kit, football home/away, sleeveless volleyball — we build for each.",
  },
  {
    n: "02",
    title: "Colours & pattern",
    body: "Choose from templates or send your own artwork. Sublimation dye holds crisp colour panels wash after wash.",
  },
  {
    n: "03",
    title: "Upload your crest",
    body: "Any format works. Our designers vector-clean it and return a proof — production waits for your sign-off.",
  },
  {
    n: "04",
    title: "Names & numbers",
    body: "Send us your squad list. Each kit is named and numbered individually and packed per player, ready to hand out.",
  },
  {
    n: "05",
    title: "Sample, produce, ship",
    body: "First-piece sample optional. Production runs 10–14 days for standard orders; expedited on request. Nationwide dispatch.",
  },
];

const PRICING = [
  {
    tier: "Academy Series",
    from: "PKR 1,800",
    per: "per kit",
    for: "Schools & academies · MOQ 15",
    inc: "Sublimated poly, single-colour crest, name + number.",
  },
  {
    tier: "Club Kit",
    from: "PKR 2,600",
    per: "per kit",
    for: "Club & tournament teams · MOQ 12",
    inc: "Performance mesh, embroidered crest, home / away option.",
  },
  {
    tier: "Elite / Match",
    from: "PKR 3,800",
    per: "per kit",
    for: "First-XI kits · MOQ 12",
    inc: "Premium moisture-wick, sublimated + embroidered detail, sample proof.",
  },
];

const TRUST = [
  { h: "Turnaround", p: "10–14 days standard from proof approval." },
  { h: "Fabric", p: "Performance moisture-wick / cotton pique / sublimated poly." },
  { h: "Bulk discount", p: "Tiered pricing from 12, 25 and 50 kits." },
  { h: "Proof-before-print", p: "No production runs without your written sign-off." },
];

function CustomJerseys() {
  const [selectedSport, setSelectedSport] = useState<"All" | "Cricket" | "Football" | "Volleyball">("All");
  const [file, setFile] = useState<string | null>(null);
  const [team, setTeam] = useState("");
  const [players, setPlayers] = useState("");

  const gallery =
    selectedSport === "All"
      ? JERSEY_DESIGNS
      : JERSEY_DESIGNS.filter((d) => d.sport === selectedSport);

  const enquiry = whatsappLink(
    [
      "Salaam! Custom jersey enquiry from lalasports.com:",
      team ? `Team: ${team}` : "",
      players ? `Squad size: ${players}` : "",
      file ? `Crest attached: ${file}` : "",
    ]
      .filter(Boolean)
      .join("\n"),
  );

  return (
    <div className="bg-bone">
      {/* Hero */}
      <section className="relative bg-forest text-bone overflow-hidden">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 pt-24 pb-24 md:pt-32 md:pb-40 grid md:grid-cols-12 gap-10 items-end">
          <div className="md:col-span-8">
            <p className="eyebrow text-sienna mb-6">The Specialty · Made in Kamra</p>
            <h1 className="font-serif text-6xl md:text-8xl lg:text-9xl leading-[0.92]">
              Custom kits, <span className="italic">not stock</span>.
            </h1>
            <p className="mt-8 max-w-xl text-bone/70 text-lg leading-relaxed">
              We manufacture team jerseys start-to-finish in our Kamra
              workshop — cricket, football, volleyball. Your colours, your
              crest, your names and numbers, on the fabric grade you choose.
            </p>
          </div>
          <div className="md:col-span-4 md:pb-4">
            <div className="border-t border-bone/20 pt-6">
              <p className="eyebrow text-bone/50 mb-2">Starts at</p>
              <p className="font-serif text-4xl">
                PKR 1,800 <span className="text-bone/50 text-lg">/ kit</span>
              </p>
              <p className="mt-2 text-xs text-bone/60">
                Team & academy MOQ 12–15.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Steps flow */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24">
        <div className="flex justify-between items-end mb-14">
          <div>
            <p className="eyebrow text-sienna mb-3">The Process</p>
            <h2 className="font-serif text-5xl md:text-6xl max-w-2xl leading-[1]">
              Five steps from your idea to fifteen kits on the pitch.
            </h2>
          </div>
        </div>
        <ol className="grid md:grid-cols-5 gap-8 md:gap-4">
          {STEPS.map((s, i) => (
            <li key={s.n} className="relative">
              {i > 0 && (
                <div className="hidden md:block absolute -left-2 top-3 w-4 h-px bg-ink/20" />
              )}
              <p className="font-serif italic text-3xl text-sienna mb-3">
                {s.n}
              </p>
              <h3 className="text-xs font-bold uppercase tracking-[0.18em] mb-3">
                {s.title}
              </h3>
              <p className="text-sm text-ink/60 leading-relaxed">{s.body}</p>
            </li>
          ))}
        </ol>
      </section>

      {/* Gallery */}
      <section className="bg-mist/40 py-24">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-6 mb-12">
            <div>
              <p className="eyebrow text-sienna mb-3">Selected work</p>
              <h2 className="font-serif text-5xl md:text-6xl">
                Kits we've built.
              </h2>
            </div>
            <div className="flex gap-2 flex-wrap">
              {(["All", "Cricket", "Football", "Volleyball"] as const).map(
                (s) => (
                  <button
                    key={s}
                    onClick={() => setSelectedSport(s)}
                    className={
                      "px-4 py-2 text-xs font-medium uppercase tracking-widest border transition-colors " +
                      (selectedSport === s
                        ? "bg-forest text-bone border-forest"
                        : "border-ink/15 hover:bg-ink hover:text-bone")
                    }
                  >
                    {s}
                  </button>
                ),
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            {gallery.map((d, i) => (
              <figure
                key={d.id}
                className={
                  "bg-bone overflow-hidden group " +
                  (i % 5 === 0 ? "md:col-span-2 md:row-span-1" : "")
                }
              >
                <div className="aspect-[4/5] overflow-hidden bg-mist">
                  <img
                    src={d.image}
                    alt={d.alt}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
                  />
                </div>
                <figcaption className="p-5">
                  <p className="eyebrow text-sienna mb-1">
                    {d.sport} · {d.palette}
                  </p>
                  <h3 className="font-serif text-2xl mb-1">{d.name}</h3>
                  <p className="text-sm text-ink/60 leading-relaxed">
                    {d.detail}
                  </p>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24">
        <p className="eyebrow text-sienna mb-3">Pricing tiers</p>
        <h2 className="font-serif text-5xl md:text-6xl mb-14 max-w-3xl">
          Priced by fabric grade, discounted by volume.
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          {PRICING.map((tier, i) => (
            <div
              key={tier.tier}
              className={
                "p-8 md:p-10 border flex flex-col " +
                (i === 1
                  ? "bg-forest text-bone border-forest md:-my-4"
                  : "bg-bone border-ink/15")
              }
            >
              <p
                className={
                  "eyebrow mb-6 " + (i === 1 ? "text-sienna" : "text-sienna")
                }
              >
                {tier.for}
              </p>
              <h3 className="font-serif text-3xl mb-2">{tier.tier}</h3>
              <p className="font-mono mb-6">
                <span className="text-xs opacity-60">from </span>
                <span className="text-2xl">{tier.from}</span>
                <span className="text-xs opacity-60"> {tier.per}</span>
              </p>
              <p
                className={
                  "text-sm leading-relaxed mb-8 " +
                  (i === 1 ? "text-bone/70" : "text-ink/60")
                }
              >
                {tier.inc}
              </p>
              <a
                href={whatsappLink(`I'd like to enquire about the ${tier.tier} custom kit tier.`)}
                target="_blank"
                rel="noopener"
                className={
                  "mt-auto text-xs font-bold uppercase tracking-[0.2em] px-6 py-3 text-center transition-colors " +
                  (i === 1
                    ? "bg-sienna text-bone hover:bg-sienna-deep"
                    : "border border-ink/20 hover:bg-ink hover:text-bone")
                }
              >
                Enquire
              </a>
            </div>
          ))}
        </div>
      </section>

      {/* Order builder */}
      <section className="bg-ink text-bone py-24">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 grid md:grid-cols-12 gap-12">
          <div className="md:col-span-5">
            <p className="eyebrow text-sienna mb-4">Start an order</p>
            <h2 className="font-serif text-5xl md:text-6xl leading-[1]">
              Tell us about your team.
            </h2>
            <p className="mt-6 text-bone/60 max-w-md leading-relaxed">
              Fill in what you know — we'll pick up the rest on WhatsApp.
              Nothing is confirmed until you approve the proof.
            </p>
          </div>
          <form
            className="md:col-span-7 space-y-6"
            onSubmit={(e) => {
              e.preventDefault();
              window.open(enquiry, "_blank");
            }}
          >
            <Field
              label="Team / club name"
              value={team}
              onChange={setTeam}
              placeholder="e.g. Kamra Cricket Club"
            />
            <Field
              label="Squad size"
              value={players}
              onChange={setPlayers}
              placeholder="e.g. 15 kits"
              type="number"
            />
            <div>
              <label className="eyebrow text-bone/60 block mb-2">
                Upload your crest (optional)
              </label>
              <input
                type="file"
                accept="image/*,.pdf,.svg,.ai,.eps"
                onChange={(e) => setFile(e.target.files?.[0]?.name ?? null)}
                className="block w-full text-sm text-bone/70 file:mr-4 file:py-3 file:px-6 file:border-0 file:bg-bone file:text-forest file:text-xs file:font-bold file:uppercase file:tracking-[0.18em] file:cursor-pointer"
              />
              {file && (
                <p className="mt-2 text-xs text-bone/60 font-mono">
                  Attached: {file}
                </p>
              )}
            </div>
            <button
              type="submit"
              className="bg-sienna text-bone px-10 py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-sienna-deep transition-colors"
            >
              Send enquiry via WhatsApp
            </button>
          </form>
        </div>
      </section>

      {/* Trust */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24 grid md:grid-cols-4 gap-10">
        {TRUST.map((t) => (
          <div key={t.h} className="border-t border-ink/15 pt-6">
            <h3 className="text-xs font-bold uppercase tracking-[0.15em] mb-3">
              {t.h}
            </h3>
            <p className="text-sm text-ink/60 leading-relaxed">{t.p}</p>
          </div>
        ))}
      </section>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="eyebrow text-bone/60 block mb-2">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-transparent border-b border-bone/30 py-3 text-bone placeholder:text-bone/30 focus:outline-none focus:border-sienna transition-colors"
      />
    </label>
  );
}
