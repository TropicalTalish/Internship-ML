import { createFileRoute, Link } from "@tanstack/react-router";
import jerseyHero from "@/assets/jersey-cricket.jpg";
import {
  PRODUCTS,
  SPORTS,
  formatPKR,
  whatsappLink,
} from "@/lib/products";
import { ProductCard } from "@/components/site/ProductCard";
import { HeroCarousel } from "@/components/site/HeroCarousel";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const featured = PRODUCTS.filter((p) => p.featured).slice(0, 6);
  const newArrivals = PRODUCTS.filter((p) => p.new);
  const sportTiles = SPORTS.filter((s) => s.slug !== "custom-jerseys");

  return (
    <div className="bg-bone text-ink">
      {/* ================ HERO CAROUSEL ================ */}
      <HeroCarousel />

      {/* ================ SHOP BY SPORT ================ */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24 md:py-32">
        <Reveal className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div className="max-w-xl">
            <p className="eyebrow text-sienna mb-4">01 / Shop by Sport</p>
            <h2 className="font-serif text-5xl md:text-6xl leading-[1.02] text-balance">
              A general sporting-goods house — with a range for every code.
            </h2>
          </div>
          <Link
            to="/shop"
            className="eyebrow text-ink border-b border-sienna pb-1 self-start md:self-end hover:text-sienna transition-colors"
          >
            Browse the full shop →
          </Link>
        </Reveal>

        <div className="grid grid-cols-12 gap-4 md:gap-6 auto-rows-[minmax(220px,auto)]">
          <Reveal className="col-span-12 md:col-span-8 md:row-span-2 aspect-[16/10] md:aspect-auto" delay={0}>
            <SportTile
              sport={sportTiles[0]}
              image={PRODUCTS[0].image}
              imageAlt={PRODUCTS[0].alt}
              large
            />
          </Reveal>
          <Reveal className="col-span-6 md:col-span-4 aspect-square" delay={80}>
            <SportTile
              sport={sportTiles[1]}
              image={PRODUCTS.find((p) => p.category === "football")!.image}
              imageAlt="Premium match football on bone background."
            />
          </Reveal>
          <Reveal className="col-span-6 md:col-span-4 aspect-square" delay={140}>
            <SportTile
              sport={sportTiles[2]}
              image={PRODUCTS.find((p) => p.category === "volleyball-badminton")!.image}
              imageAlt="Match-quality volleyball, forest and bone panels."
            />
          </Reveal>
          <Reveal className="col-span-6 md:col-span-6 aspect-[16/10]" delay={200}>
            <SportTile
              sport={sportTiles[3]}
              image={PRODUCTS.find((p) => p.category === "fitness")!.image}
              imageAlt="Training kit — agility ladder, cones, resistance band."
            />
          </Reveal>
          <Reveal className="col-span-6 md:col-span-6 aspect-[16/10]" delay={260}>
            <SportTile
              sport={sportTiles[4]}
              image={PRODUCTS.find((p) => p.category === "shoes")!.image}
              imageAlt="Low-top court shoe in forest, bone and burnt sienna."
            />
          </Reveal>
        </div>
      </section>

      {/* ================ CUSTOM JERSEYS — FLAGSHIP ================ */}
      <section className="bg-forest text-bone py-24 md:py-32 relative overflow-hidden">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid md:grid-cols-2 gap-14 lg:gap-24 items-center">
            <Reveal className="relative order-2 md:order-1">
              <div className="absolute -top-16 -left-6 font-serif text-[10rem] md:text-[14rem] leading-none text-bone/5 select-none pointer-events-none">
                Bespoke
              </div>
              <img
                src={jerseyHero}
                alt="Custom forest and burnt sienna cricket jersey with Khan / 10 on the back."
                loading="lazy"
                width={1280}
                height={1600}
                className="relative w-full aspect-[4/5] object-cover"
              />
            </Reveal>
            <Reveal className="order-1 md:order-2" delay={120}>
              <p className="eyebrow text-sienna mb-4">The Specialty</p>
              <h2 className="font-serif text-5xl md:text-7xl leading-[1] mb-6">
                Your team, made <span className="italic">in Kamra</span>.
              </h2>
              <p className="text-bone/70 text-lg leading-relaxed max-w-lg mb-12">
                Every other sports shop stocks the same jerseys off the shelf.
                We manufacture yours — the fabric, the colours, the crest, the
                names, the numbers — start to finish, in-house.
              </p>

              <ol className="space-y-8">
                {[
                  {
                    n: "01",
                    h: "Choose your kit",
                    p: "Cricket, football or volleyball. Colour kit, whites, sleeveless, long-sleeve. Fabric grade for performance or price.",
                  },
                  {
                    n: "02",
                    h: "Design your identity",
                    p: "Upload your crest and specify colours. Our design team returns a proof within 48 hours — no production without your sign-off.",
                  },
                  {
                    n: "03",
                    h: "Names, numbers, delivered",
                    p: "Each player named and numbered individually, kits packed per player. Ships nationwide inside 14 days for standard orders.",
                  },
                ].map((s, i) => (
                  <Reveal
                    key={s.n}
                    as="li"
                    delay={200 + i * 80}
                    className="flex gap-6 border-t border-bone/15 pt-6"
                  >
                    <span className="font-serif italic text-3xl text-sienna leading-none shrink-0 w-10">
                      {s.n}
                    </span>
                    <div>
                      <h3 className="text-bone font-sans text-xs font-bold uppercase tracking-[0.2em] mb-2">
                        {s.h}
                      </h3>
                      <p className="text-bone/60 text-sm leading-relaxed max-w-sm">
                        {s.p}
                      </p>
                    </div>
                  </Reveal>
                ))}
              </ol>

              <div className="mt-12 flex flex-wrap gap-3">
                <Link
                  to="/custom-jerseys"
                  className="bg-sienna text-bone px-8 py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-sienna-deep hover:-translate-y-0.5 transition-all"
                >
                  Start a custom order
                </Link>
                <a
                  href={whatsappLink(
                    "Salaam! I'd like to enquire about custom team jerseys.",
                  )}
                  target="_blank"
                  rel="noopener"
                  className="border border-bone/30 text-bone px-8 py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-bone hover:text-forest transition-colors"
                >
                  WhatsApp us
                </a>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ================ FEATURED — BENTO ================ */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24 md:py-32">
        <Reveal className="flex justify-between items-end mb-14">
          <div>
            <p className="eyebrow text-sienna mb-4">02 / Featured Equipment</p>
            <h2 className="font-serif text-5xl md:text-6xl">Best sellers, this week.</h2>
          </div>
          <Link
            to="/shop"
            className="eyebrow text-ink border-b border-sienna pb-1 hover:text-sienna transition-colors"
          >
            View all →
          </Link>
        </Reveal>

        {/* Bento */}
        <div className="grid grid-cols-4 gap-6">
          <Reveal className="col-span-4 md:col-span-2 md:row-span-2">
            <Link
              to="/product/$id"
              params={{ id: featured[0].id }}
              className="group block h-full card-lift"
            >
              <div className="relative overflow-hidden bg-mist/40 aspect-square md:aspect-auto md:h-full">
                <img
                  src={featured[0].image}
                  alt={featured[0].alt}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.05]"
                />
                <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-ink/60 to-transparent">
                  <p className="eyebrow text-bone/70 mb-2">
                    {featured[0].category} · Flagship
                  </p>
                  <h3 className="font-serif text-bone text-3xl md:text-4xl leading-tight">
                    {featured[0].name}
                  </h3>
                  <p className="mt-2 text-bone/80 font-mono text-sm">
                    {formatPKR(featured[0].price)}
                  </p>
                </div>
              </div>
            </Link>
          </Reveal>

          {featured.slice(1, 5).map((p, i) => (
            <Reveal key={p.id} className="col-span-2 md:col-span-1" delay={80 + i * 60}>
              <ProductCard product={p} size="sm" />
            </Reveal>
          ))}
        </div>
      </section>

      {/* ================ NEW ARRIVALS STRIP ================ */}
      {newArrivals.length > 0 && (
        <section className="border-y border-ink/10 bg-mist/30 py-16">
          <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
            <Reveal className="flex justify-between items-baseline mb-10">
              <h2 className="font-serif text-3xl md:text-4xl">Just landed</h2>
              <Link to="/shop" className="eyebrow text-ink/60 hover:text-sienna">
                View all →
              </Link>
            </Reveal>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {newArrivals.slice(0, 4).map((p, i) => (
                <Reveal key={p.id} delay={i * 70}>
                  <ProductCard product={p} size="sm" />
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ================ TRUST STRIP ================ */}
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 py-24">
        <div className="grid md:grid-cols-4 gap-10 md:gap-14">
          {[
            {
              n: "α",
              h: "WhatsApp-first ordering",
              p: "Talk to a person, not a chatbot. Every enquiry gets a direct reply from our team.",
            },
            {
              n: "β",
              h: "Nationwide dispatch",
              p: "Shipped from Kamra to every province — orders confirmed on WhatsApp, tracked on delivery.",
            },
            {
              n: "γ",
              h: "Tested quality",
              p: "Every piece of gear is checked before it ships. If it isn't right, we make it right.",
            },
            {
              n: "δ",
              h: "Made-to-order kits",
              p: "Custom jerseys manufactured on-site — no middlemen, no overseas turnaround.",
            },
          ].map((c, i) => (
            <Reveal key={c.h} delay={i * 70} className="border-t border-ink/15 pt-6">
              <p className="font-serif italic text-3xl text-sienna leading-none mb-4">{c.n}</p>
              <h3 className="text-sm font-bold uppercase tracking-[0.15em] mb-3">{c.h}</h3>
              <p className="text-sm text-ink/60 leading-relaxed">{c.p}</p>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ================ WHATSAPP CTA ================ */}
      <section className="px-6 lg:px-10 pb-24">
        <Reveal className="max-w-[1400px] mx-auto bg-sienna text-bone p-10 md:p-16 flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
          <div>
            <p className="eyebrow text-bone/70 mb-3">Ready when you are</p>
            <h2 className="font-serif text-4xl md:text-5xl leading-tight max-w-md">
              Send us a message — we'll build your order together.
            </h2>
          </div>
          <a
            href={whatsappLink(
              "Salaam! I'd like to place an order with Lala Sports.",
            )}
            target="_blank"
            rel="noopener"
            className="bg-bone text-sienna px-8 py-5 text-xs font-bold uppercase tracking-[0.2em] hover:-translate-y-0.5 hover:scale-[1.02] transition-transform shrink-0"
          >
            Chat on WhatsApp
          </a>
        </Reveal>
      </section>
    </div>
  );
}

function SportTile({
  sport,
  image,
  imageAlt,
  large,
}: {
  sport: (typeof SPORTS)[number];
  image: string;
  imageAlt: string;
  large?: boolean;
}) {
  return (
    <Link
      to="/shop/$category"
      params={{ category: sport.slug }}
      className="group relative overflow-hidden bg-mist block w-full h-full"
    >
      <img
        src={image}
        alt={imageAlt}
        loading="lazy"
        className="absolute inset-0 w-full h-full object-cover transition-transform duration-[1000ms] ease-out group-hover:scale-[1.06]"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-transparent transition-opacity duration-500 group-hover:from-ink/80" />
      <div className="absolute inset-0 p-6 md:p-8 flex flex-col justify-between">
        <p className="eyebrow text-bone/70">{sport.eyebrow}</p>
        <div className="transition-transform duration-500 ease-out group-hover:-translate-y-1">
          <h3
            className={
              "font-serif text-bone leading-none " +
              (large ? "text-5xl md:text-7xl" : "text-3xl md:text-4xl")
            }
          >
            {sport.name}
          </h3>
          {large && (
            <p className="mt-4 text-bone/80 text-sm max-w-md leading-relaxed">
              {sport.description}
            </p>
          )}
          <p className="mt-4 eyebrow text-sienna">Shop →</p>
        </div>
      </div>
    </Link>
  );
}
