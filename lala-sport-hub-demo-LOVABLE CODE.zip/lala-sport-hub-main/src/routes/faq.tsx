import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Ordering, Delivery, Custom Jerseys | Lala Sports" },
      {
        name: "description",
        content:
          "Answers to common questions about ordering from Lala Sports — WhatsApp orders, delivery across Pakistan, custom jersey turnaround, MOQs and payment.",
      },
      { property: "og:title", content: "FAQ | Lala Sports" },
    ],
  }),
  component: FAQ,
});

const QA = [
  {
    q: "How do I place an order?",
    a: "Every order runs through WhatsApp. Send us the product name (or a link) with your city and quantity, we confirm availability and total, then dispatch on payment confirmation.",
  },
  {
    q: "Do you deliver across Pakistan?",
    a: "Yes — nationwide. Delivery in 2–5 working days depending on city. Charges are shared on WhatsApp before you confirm.",
  },
  {
    q: "How does payment work?",
    a: "Bank transfer, JazzCash and EasyPaisa are all supported. Cash on delivery is available for select cities on smaller orders.",
  },
  {
    q: "How long do custom jerseys take?",
    a: "Standard turnaround is 10–14 days from the moment you approve the design proof. Expedited production is available for tournament deadlines — ask us.",
  },
  {
    q: "What's the minimum order for custom jerseys?",
    a: "12 kits for club and elite tiers, 15 kits for the academy tier. Below that, we can still make one-off pieces at a per-item rate — WhatsApp us.",
  },
  {
    q: "Can I see a sample before you produce the full run?",
    a: "Yes. A first-piece sample is included in the elite tier and available on request in the club tier. No production runs without your written sign-off on a proof.",
  },
  {
    q: "Do you use real branded gear (Nike, Kookaburra, etc.)?",
    a: "We stock our own house-brand gear, made to competition-grade specs, so you're not paying a licensing tax. Every product is inspected before it ships.",
  },
];

function FAQ() {
  return (
    <div className="bg-bone">
      <section className="max-w-[1000px] mx-auto px-6 lg:px-10 py-24">
        <p className="eyebrow text-sienna mb-6">FAQ</p>
        <h1 className="font-serif text-6xl md:text-7xl leading-[0.98] mb-16">
          Common questions, straight answers.
        </h1>

        <ul className="divide-y divide-ink/10 border-y border-ink/10">
          {QA.map((item, i) => (
            <li key={item.q} className="py-8 grid md:grid-cols-[80px_1fr] gap-6">
              <p className="font-serif italic text-2xl text-sienna">
                {String(i + 1).padStart(2, "0")}
              </p>
              <div>
                <h2 className="font-serif text-2xl mb-3">{item.q}</h2>
                <p className="text-ink/70 leading-relaxed">{item.a}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
