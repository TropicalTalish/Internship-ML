import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { PRODUCTS, SPORTS, formatPKR, whatsappLink } from "@/lib/products";
import { ProductCard } from "@/components/site/ProductCard";

export const Route = createFileRoute("/product/$id")({
  beforeLoad: ({ params }) => {
    if (!PRODUCTS.find((p) => p.id === params.id)) throw notFound();
  },
  head: ({ params }) => {
    const p = PRODUCTS.find((x) => x.id === params.id);
    if (!p) return { meta: [{ title: "Product | Lala Sports" }] };
    return {
      meta: [
        { title: `${p.name} — ${formatPKR(p.price)} | Lala Sports` },
        { name: "description", content: p.description },
        { property: "og:title", content: `${p.name} | Lala Sports` },
        { property: "og:description", content: p.description },
        { property: "og:image", content: p.image },
        { property: "og:type", content: "product" },
        { name: "twitter:image", content: p.image },
      ],
    };
  },
  component: ProductPage,
  notFoundComponent: () => (
    <div className="p-24 text-center">Product not found.</div>
  ),
  errorComponent: ({ error }) => (
    <div className="p-24 text-center text-sm text-ink/60">
      Couldn't load this product. {error.message}
    </div>
  ),
});

function ProductPage() {
  const { id } = Route.useParams();
  const product = PRODUCTS.find((p) => p.id === id)!;
  const sport = SPORTS.find((s) => s.slug === product.category)!;
  const related = PRODUCTS.filter(
    (p) => p.category === product.category && p.id !== product.id,
  ).slice(0, 4);

  return (
    <div className="bg-bone">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-10">
        <nav className="eyebrow text-ink/40 flex gap-2">
          <Link to="/shop" className="hover:text-ink">Shop</Link>
          <span>/</span>
          <Link
            to="/shop/$category"
            params={{ category: product.category }}
            className="hover:text-ink"
          >
            {sport.name}
          </Link>
          <span>/</span>
          <span className="text-ink/70">{product.name}</span>
        </nav>
      </div>

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 pb-24 grid md:grid-cols-2 gap-10 md:gap-16">
        <div className="bg-mist/40 aspect-[4/5] overflow-hidden">
          <img
            src={product.image}
            alt={product.alt}
            loading="eager"
            className="w-full h-full object-cover"
          />
        </div>

        <div className="flex flex-col">
          <p className="eyebrow text-sienna mb-4">{sport.name}</p>
          <h1 className="font-serif text-5xl md:text-6xl leading-[1.02]">
            {product.name}
          </h1>
          <p className="mt-4 text-xl italic font-serif text-ink/60">
            {product.tagline}
          </p>

          <p className="mt-8 font-mono text-2xl">{formatPKR(product.price)}</p>
          <p className="mt-1 eyebrow text-ink/50">
            {product.stock === "in-stock" ? "In stock" : "Low stock"}
          </p>

          <p className="mt-8 text-ink/70 leading-relaxed max-w-md">
            {product.description}
          </p>

          <dl className="mt-10 border-t border-ink/10">
            {product.specs.map((s) => (
              <div
                key={s.label}
                className="grid grid-cols-2 py-3 border-b border-ink/10 text-sm"
              >
                <dt className="eyebrow text-ink/50">{s.label}</dt>
                <dd className="text-ink/80">{s.value}</dd>
              </div>
            ))}
          </dl>

          <div className="mt-10 flex flex-wrap gap-3">
            <a
              href={whatsappLink(
                `Salaam! I'd like to order the ${product.name} (${formatPKR(product.price)}) from Lala Sports.`,
              )}
              target="_blank"
              rel="noopener"
              className="bg-whatsapp text-forest-deep px-8 py-4 text-xs font-bold uppercase tracking-[0.2em] hover:brightness-95 transition-all"
            >
              Order via WhatsApp
            </a>
            <Link
              to="/shop/$category"
              params={{ category: product.category }}
              className="border border-ink/20 px-8 py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-ink hover:text-bone transition-colors"
            >
              ← Back to {sport.name}
            </Link>
          </div>

          <p className="mt-8 text-xs text-ink/50 max-w-md leading-relaxed">
            Ordering is WhatsApp-first: message us with your details, we confirm
            availability and dispatch. Nationwide delivery inside Pakistan.
          </p>
        </div>
      </section>

      {related.length > 0 && (
        <section className="border-t border-ink/10 bg-mist/30 py-20">
          <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
            <h2 className="font-serif text-3xl md:text-4xl mb-10">
              You may also like
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} size="sm" />
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
