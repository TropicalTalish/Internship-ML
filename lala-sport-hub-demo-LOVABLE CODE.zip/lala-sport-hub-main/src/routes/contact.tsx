import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CONTACT, whatsappLink } from "@/lib/products";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — WhatsApp, Phone & Facebook | Lala Sports" },
      {
        name: "description",
        content:
          "Contact Lala Sports in Kamra, Pakistan. WhatsApp 0307-8936637 for orders and custom jersey enquiries, or visit our workshop in Waisa.",
      },
      { property: "og:title", content: "Contact | Lala Sports" },
      {
        property: "og:description",
        content: "WhatsApp, phone, Facebook — get in touch with Lala Sports.",
      },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [name, setName] = useState("");
  const [msg, setMsg] = useState("");

  const send = whatsappLink(
    `Salaam! ${name ? `This is ${name}. ` : ""}${msg || "I'd like to enquire about Lala Sports."}`,
  );

  return (
    <div className="bg-bone">
      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 pt-24 pb-16">
        <p className="eyebrow text-sienna mb-6">Get in touch</p>
        <h1 className="font-serif text-6xl md:text-8xl leading-[0.95] max-w-4xl">
          The <span className="italic">fastest</span> way to reach us is WhatsApp.
        </h1>
      </section>

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 pb-24 grid md:grid-cols-12 gap-12">
        <div className="md:col-span-5 space-y-10">
          {[
            {
              label: "WhatsApp",
              value: CONTACT.phone,
              href: whatsappLink("Salaam! I have an enquiry."),
              cta: "Open chat",
            },
            {
              label: "Phone",
              value: CONTACT.phone,
              href: `tel:${CONTACT.phone}`,
              cta: "Call",
            },
            {
              label: "Facebook",
              value: "@lalasports",
              href: CONTACT.facebook,
              cta: "Visit page",
            },
            {
              label: "Studio",
              value: CONTACT.location,
              href: "https://maps.google.com/?q=Kamra,+KPK,+Pakistan",
              cta: "Open in maps",
            },
          ].map((c) => (
            <div key={c.label} className="border-t border-ink/15 pt-6">
              <p className="eyebrow text-ink/50 mb-2">{c.label}</p>
              <p className="font-serif text-3xl mb-3">{c.value}</p>
              <a
                href={c.href}
                target="_blank"
                rel="noopener"
                className="eyebrow text-sienna border-b border-sienna pb-1 hover:text-sienna-deep"
              >
                {c.cta} →
              </a>
            </div>
          ))}
        </div>

        <form
          className="md:col-span-7 bg-forest text-bone p-10 md:p-14"
          onSubmit={(e) => {
            e.preventDefault();
            window.open(send, "_blank");
          }}
        >
          <p className="eyebrow text-sienna mb-4">Quick enquiry</p>
          <h2 className="font-serif text-4xl md:text-5xl mb-10">
            Draft your message — we'll open WhatsApp with it ready to send.
          </h2>
          <div className="space-y-6">
            <label className="block">
              <span className="eyebrow text-bone/60 block mb-2">Your name</span>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-transparent border-b border-bone/30 py-3 focus:outline-none focus:border-sienna text-bone"
              />
            </label>
            <label className="block">
              <span className="eyebrow text-bone/60 block mb-2">Message</span>
              <textarea
                value={msg}
                onChange={(e) => setMsg(e.target.value)}
                rows={5}
                placeholder="What are you looking for? Include quantities and any details."
                className="w-full bg-transparent border-b border-bone/30 py-3 focus:outline-none focus:border-sienna text-bone placeholder:text-bone/30 resize-none"
              />
            </label>
            <button
              type="submit"
              className="bg-sienna text-bone px-10 py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-sienna-deep transition-colors"
            >
              Send via WhatsApp
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
