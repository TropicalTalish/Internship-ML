import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { SiteHeader } from "@/components/site/SiteHeader";
import { SiteFooter } from "@/components/site/SiteFooter";
import { WhatsAppFloat } from "@/components/site/WhatsAppFloat";
import { BackToTop } from "@/components/site/BackToTop";

function NotFoundComponent() {
  return (
    <div className="flex min-h-[70vh] items-center justify-center bg-bone px-4">
      <div className="max-w-md text-center">
        <p className="eyebrow text-sienna mb-4">404 / Off the pitch</p>
        <h1 className="font-serif text-6xl text-ink">Page not found</h1>
        <p className="mt-4 text-sm text-ink/60">
          The page you're looking for has moved, or was never here.
        </p>
        <div className="mt-8">
          <Link
            to="/"
            className="inline-flex items-center justify-center bg-forest text-bone px-6 py-3 text-xs font-bold uppercase tracking-[0.18em] hover:bg-ink transition-colors"
          >
            Return home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-[70vh] items-center justify-center bg-bone px-4">
      <div className="max-w-md text-center">
        <p className="eyebrow text-sienna mb-4">Something went wrong</p>
        <h1 className="font-serif text-4xl text-ink">This page didn't load</h1>
        <p className="mt-4 text-sm text-ink/60">
          Try refreshing, or head back to the home page.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="bg-forest text-bone px-6 py-3 text-xs font-bold uppercase tracking-[0.18em] hover:bg-ink"
          >
            Try again
          </button>
          <a
            href="/"
            className="border border-ink/20 px-6 py-3 text-xs font-bold uppercase tracking-[0.18em] hover:bg-ink hover:text-bone transition-colors"
          >
            Home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#1B2B21" },
      {
        title:
          "Lala Sports — Premium Sports Equipment & Custom Team Jerseys in Kamra, Pakistan",
      },
      {
        name: "description",
        content:
          "Lala Sports is a premium multi-sport equipment shop in Waisa, Kamra — cricket, football, volleyball, badminton, fitness and shoes, plus bespoke team jersey manufacturing. WhatsApp ordering.",
      },
      { name: "author", content: "Lala Sports" },
      { property: "og:site_name", content: "Lala Sports" },
      { property: "og:title", content: "Lala Sports — Gear Up. Play Harder." },
      {
        property: "og:description",
        content:
          "Premium sports equipment and custom team jerseys from Waisa, Kamra, Pakistan.",
      },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "en_PK" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      {
        rel: "preconnect",
        href: "https://fonts.gstatic.com",
        crossOrigin: "anonymous",
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();
  const pathname = router.state.location.pathname;

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col">
        <SiteHeader />
        <main className="flex-1">
          <div key={pathname} className="animate-route">
            <Outlet />
          </div>
        </main>
        <SiteFooter />
        <BackToTop />
        <WhatsAppFloat />
      </div>
    </QueryClientProvider>
  );
}
