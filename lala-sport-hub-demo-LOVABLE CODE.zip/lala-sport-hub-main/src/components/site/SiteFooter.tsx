import { Link } from "@tanstack/react-router";
import { CONTACT } from "@/lib/products";

export function SiteFooter() {
  return (
    <footer className="bg-forest text-bone/70 pt-20 pb-10 mt-24">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-16 border-b border-bone/10">
          <div className="md:col-span-5">
            <Link
              to="/"
              className="font-serif text-4xl text-bone leading-none tracking-tight"
            >
              Lala <span className="italic">Sports</span>
            </Link>
            <p className="mt-6 max-w-md leading-relaxed text-sm">
              A general sporting-goods house from Waisa, Kamra — supplying gear
              across cricket, football and court sports, and manufacturing
              bespoke team kits for clubs, schools and academies across
              Pakistan.
            </p>
          </div>

          <div className="md:col-span-2">
            <h4 className="eyebrow text-bone mb-5">Shop</h4>
            <ul className="space-y-3 text-sm">
              <li><Link to="/shop/cricket" className="hover:text-bone">Cricket</Link></li>
              <li><Link to="/shop/football" className="hover:text-bone">Football</Link></li>
              <li><Link to="/shop/volleyball-badminton" className="hover:text-bone">Court Sports</Link></li>
              <li><Link to="/shop/fitness" className="hover:text-bone">Fitness</Link></li>
              <li><Link to="/shop/shoes" className="hover:text-bone">Shoes</Link></li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <h4 className="eyebrow text-bone mb-5">Services</h4>
            <ul className="space-y-3 text-sm">
              <li><Link to="/custom-jerseys" className="hover:text-bone">Custom Jerseys</Link></li>
              <li><Link to="/about" className="hover:text-bone">About</Link></li>
              <li><Link to="/faq" className="hover:text-bone">FAQ</Link></li>
              <li><Link to="/contact" className="hover:text-bone">Contact</Link></li>
            </ul>
          </div>

          <div className="md:col-span-3">
            <h4 className="eyebrow text-bone mb-5">Studio</h4>
            <address className="not-italic text-sm space-y-3 leading-relaxed">
              <div>{CONTACT.location}</div>
              <div>
                <a href={`tel:${CONTACT.phone}`} className="hover:text-bone">
                  {CONTACT.phone}
                </a>
              </div>
              <div className="pt-2">
                <a
                  href={CONTACT.facebook}
                  target="_blank"
                  rel="noopener"
                  className="text-bone hover:text-sienna"
                >
                  Facebook →
                </a>
              </div>
            </address>
          </div>
        </div>

        <div className="pt-8 flex flex-col md:flex-row justify-between gap-4 eyebrow text-bone/40">
          <p>© {new Date().getFullYear()} Lala Sports — Kamra, KPK.</p>
          <p>Built for competitors.</p>
        </div>
      </div>
    </footer>
  );
}
