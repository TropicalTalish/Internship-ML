import { Link } from "@tanstack/react-router";
import { formatPKR, type Product } from "@/lib/products";

export function ProductCard({
  product,
  size = "md",
}: {
  product: Product;
  size?: "sm" | "md" | "lg";
}) {
  const aspect =
    size === "lg" ? "aspect-[4/5]" : size === "sm" ? "aspect-square" : "aspect-[4/5]";
  return (
    <Link
      to="/product/$id"
      params={{ id: product.id }}
      className="group block card-lift"
    >
      <div className={`relative overflow-hidden bg-mist/40 ${aspect}`}>
        <img
          src={product.image}
          alt={product.alt}
          loading="lazy"
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.06]"
        />
        {product.new && (
          <span className="absolute top-3 left-3 eyebrow bg-forest text-bone px-2 py-1 transition-transform duration-300 group-hover:-translate-y-0.5">
            New
          </span>
        )}
        {product.stock === "low-stock" && (
          <span className="absolute top-3 right-3 eyebrow text-sienna">
            Low stock
          </span>
        )}
      </div>
      <div className="mt-4 flex justify-between items-start gap-4">
        <div>
          <p className="eyebrow text-ink/40 mb-1">{product.category.replace("-", " / ")}</p>
          <h3
            className={
              (size === "lg" ? "font-serif text-xl leading-tight" : "text-sm font-medium leading-tight") +
              " transition-colors group-hover:text-sienna"
            }
          >
            {product.name}
          </h3>
        </div>
        <p className="text-sm font-mono whitespace-nowrap text-ink/70">
          {formatPKR(product.price)}
        </p>
      </div>
    </Link>
  );
}
