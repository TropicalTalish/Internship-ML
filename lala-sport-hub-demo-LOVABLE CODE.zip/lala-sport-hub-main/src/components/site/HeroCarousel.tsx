import { Link } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import heroImg from "@/assets/hero-athlete.jpg";
import jerseyImg from "@/assets/jersey-cricket.jpg";
import shoesImg from "@/assets/product-shoes.jpg";
import { cn } from "@/lib/utils";

type Slide = {
  key: string;
  image: string;
  alt: string;
  eyebrow: string;
  titleTop: string;
  titleBottom: React.ReactNode;
  body: string;
  primary: { to: string; params?: Record<string, string>; label: string };
  secondary?: { to: string; params?: Record<string, string>; label: string };
  focus?: string; // object-position
  titleClass?: string;

};

const SLIDES: Slide[] = [
  {
    key: "hero",
    image: heroImg,
    alt: "Cricket batsman playing a cover drive under stadium floodlights, dramatic side light and motion blur.",
    eyebrow: "Est. Kamra · Kit for every sport",
    titleTop: "Gear up.",
    titleBottom: (
      <>
        Play <span className="italic">harder</span>.
      </>
    ),
    body: "Everything you need to compete — cricket, football, court sports, training, footwear — plus the finest custom team kits made in Pakistan.",
    primary: { to: "/shop", label: "Shop All Sports" },
    secondary: { to: "/custom-jerseys", label: "Explore Custom Jerseys" },
  },
  {
    key: "jerseys",
    image: jerseyImg,
    alt: "Custom forest-green and burnt sienna cricket jersey, back detail with player name and number.",
    eyebrow: "The Specialty · Made in Kamra",
    titleTop: "Your team. Your colours.",
    titleBottom: (
      <>
        Made <span className="italic">to order</span>.
      </>
    ),
    body: "Bespoke jerseys manufactured in-house — cricket, football, volleyball. Your crest, your palette, every player named and numbered.",
    primary: { to: "/custom-jerseys", label: "Design Your Jersey" },
    secondary: { to: "/shop", label: "Browse the shop" },
    focus: "center",
    titleClass: "text-[clamp(2.5rem,7vw,6.5rem)]",

  },
  {
    key: "footwear",
    image: shoesImg,
    alt: "Low-top court shoe in forest, bone and burnt sienna — new footwear season.",
    eyebrow: "New Season · Footwear",
    titleTop: "Grip. Cushion.",
    titleBottom: (
      <>
        Just <span className="italic">landed</span>.
      </>
    ),
    body: "Court, road and cross-training silhouettes engineered for the way each sport moves. Fresh drops now in the shop.",
    primary: { to: "/shop/$category", params: { category: "shoes" }, label: "Shop Footwear" },
    secondary: { to: "/shop", label: "See what's new" },
  },
];

const INTERVAL = 5500;

export function HeroCarousel() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [tick, setTick] = useState(0); // restarts progress animation
  const timerRef = useRef<number | null>(null);

  const go = useCallback((n: number) => {
    setIndex(((n % SLIDES.length) + SLIDES.length) % SLIDES.length);
    setTick((t) => t + 1);
  }, []);

  const next = useCallback(() => go(index + 1), [go, index]);
  const prev = useCallback(() => go(index - 1), [go, index]);

  useEffect(() => {
    if (paused) return;
    timerRef.current = window.setTimeout(
      () => setIndex((i) => (i + 1) % SLIDES.length),
      INTERVAL,
    );
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, [index, paused]);

  // Reset progress bar whenever index changes
  useEffect(() => {
    setTick((t) => t + 1);
  }, [index]);

  return (
    <section
      className="relative h-[92vh] min-h-[640px] overflow-hidden bg-forest-deep group/hero"
      aria-roledescription="carousel"
      aria-label="Featured highlights"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={() => setPaused(true)}
      onTouchEnd={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
    >
      {/* Slides — crossfade */}
      {SLIDES.map((s, i) => (
        <div
          key={s.key}
          className={cn(
            "absolute inset-0 transition-opacity duration-[900ms] ease-[cubic-bezier(0.22,0.61,0.36,1)]",
            i === index ? "opacity-100" : "opacity-0 pointer-events-none",
          )}
          aria-hidden={i !== index}
        >
          <img
            src={s.image}
            alt={s.alt}
            width={1920}
            height={1280}
            className={cn(
              "absolute inset-0 w-full h-full object-cover opacity-80 transition-transform duration-[7000ms] ease-out",
              i === index ? "scale-105" : "scale-100",
            )}
            style={{ objectPosition: s.focus ?? "center" }}
            loading={i === 0 ? "eager" : "lazy"}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-forest-deep via-forest-deep/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-forest-deep/70 via-transparent to-transparent" />

          <div className="relative h-full max-w-[1400px] mx-auto px-6 lg:px-10 flex flex-col justify-end pb-24 md:pb-32">
            {i === index && (
              <>
                <p
                  key={`${s.key}-eyebrow-${tick}`}
                  className="animate-reveal eyebrow text-sienna mb-6"
                >
                  {s.eyebrow}
                </p>
                <h1
                  key={`${s.key}-title-${tick}`}
                  className={`animate-reveal [animation-delay:120ms] font-serif text-bone leading-[0.92] max-w-5xl ${s.titleClass ?? "text-[clamp(3.5rem,10vw,9rem)]"}`}
                >
                  {s.titleTop}
                  <br />
                  {s.titleBottom}
                </h1>
                <p
                  key={`${s.key}-body-${tick}`}
                  className="animate-reveal [animation-delay:280ms] mt-6 text-bone/80 text-lg md:text-xl max-w-xl leading-relaxed"
                >
                  {s.body}
                </p>
                <div
                  key={`${s.key}-ctas-${tick}`}
                  className="animate-reveal [animation-delay:420ms] mt-10 flex flex-wrap gap-3"
                >
                  <Link
                    to={s.primary.to}
                    params={s.primary.params as never}
                    className="bg-sienna text-bone px-8 py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-sienna-deep hover:-translate-y-0.5 transition-all"
                  >
                    {s.primary.label}
                  </Link>
                  {s.secondary && (
                    <Link
                      to={s.secondary.to}
                      params={s.secondary.params as never}
                      className="border border-bone/30 text-bone px-8 py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-bone hover:text-forest transition-colors"
                    >
                      {s.secondary.label}
                    </Link>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      ))}

      {/* Prev / Next arrows */}
      <button
        type="button"
        aria-label="Previous slide"
        onClick={prev}
        className="absolute left-4 md:left-6 top-1/2 -translate-y-1/2 z-10 hidden md:flex h-11 w-11 items-center justify-center rounded-full bg-bone/10 text-bone backdrop-blur-sm border border-bone/20 opacity-0 group-hover/hero:opacity-100 hover:bg-bone hover:text-forest transition-all"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>
      <button
        type="button"
        aria-label="Next slide"
        onClick={next}
        className="absolute right-4 md:right-6 top-1/2 -translate-y-1/2 z-10 hidden md:flex h-11 w-11 items-center justify-center rounded-full bg-bone/10 text-bone backdrop-blur-sm border border-bone/20 opacity-0 group-hover/hero:opacity-100 hover:bg-bone hover:text-forest transition-all"
      >
        <ChevronRight className="h-5 w-5" />
      </button>

      {/* Dot indicators with progress fill */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex items-center gap-3">
        {SLIDES.map((s, i) => {
          const active = i === index;
          return (
            <button
              key={s.key}
              type="button"
              aria-label={`Go to slide ${i + 1}`}
              aria-current={active}
              onClick={() => go(i)}
              className="group/dot relative h-1.5 overflow-hidden transition-all"
              style={{ width: active ? 56 : 24 }}
            >
              <span className="absolute inset-0 bg-bone/30" />
              {active && (
                <span
                  key={tick}
                  className="absolute inset-y-0 left-0 w-full bg-bone origin-left"
                  style={{
                    animation: paused
                      ? "none"
                      : `carousel-progress ${INTERVAL}ms linear forwards`,
                  }}
                />
              )}
            </button>
          );
        })}
      </div>
    </section>
  );
}
