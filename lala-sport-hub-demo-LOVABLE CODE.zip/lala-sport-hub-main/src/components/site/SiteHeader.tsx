import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CONTACT, whatsappLink } from "@/lib/products";
import { cn } from "@/lib/utils";

type NavItem = { to: string; label: string; accent?: boolean };
const NAV: NavItem[] = [
  { to: "/shop", label: "Shop" },
  { to: "/shop/cricket", label: "Cricket" },
  { to: "/shop/football", label: "Football" },
  { to: "/custom-jerseys", label: "Custom Jerseys", accent: true },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 12);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-40 transition-all duration-300 ease-out",
        scrolled
          ? "bg-bone/90 backdrop-blur border-b border-ink/10 shadow-[0_1px_20px_-8px_oklch(0.2_0.03_150/0.25)]"
          : "bg-bone/70 backdrop-blur-sm border-b border-transparent",
      )}
    >
      <div
        className={cn(
          "max-w-[1400px] mx-auto px-6 lg:px-10 flex items-center justify-between gap-8 transition-all duration-300 ease-out",
          scrolled ? "h-14" : "h-16",
        )}
      >
        <div className="flex items-center gap-10">
          <Link
            to="/"
            className={cn(
              "font-serif leading-none tracking-tight text-forest transition-all duration-300",
              scrolled ? "text-[1.35rem]" : "text-[1.55rem]",
            )}
            aria-label="Lala Sports — home"
          >
            Lala <span className="italic">Sports</span>
          </Link>
          <nav className="hidden lg:flex items-center gap-7 text-[13px] font-medium">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "relative py-1 transition-colors",
                  "after:content-[''] after:absolute after:left-0 after:right-0 after:-bottom-0.5 after:h-px after:bg-sienna after:origin-left after:scale-x-0 after:transition-transform after:duration-300 hover:after:scale-x-100",
                  item.accent
                    ? "text-sienna hover:text-sienna-deep"
                    : "text-ink/70 hover:text-ink",
                )}
                activeProps={{ className: "text-ink font-semibold" }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <span className="hidden md:block eyebrow text-ink/50">
            {CONTACT.phone}
          </span>
          <a
            href={whatsappLink("Salaam! I have an enquiry about Lala Sports.")}
            target="_blank"
            rel="noopener"
            className="hidden sm:inline-flex bg-forest text-bone px-4 py-2 text-[11px] font-bold uppercase tracking-[0.18em] hover:bg-ink hover:-translate-y-0.5 transition-all"
          >
            Order via WhatsApp
          </a>
          <button
            aria-label="Toggle navigation"
            aria-expanded={open}
            className="lg:hidden p-2 -mr-2 text-ink"
            onClick={() => setOpen((o) => !o)}
          >
            <div className="w-5 space-y-1.5">
              <span
                className={cn(
                  "block h-px bg-current transition-transform duration-300 origin-center",
                  open && "translate-y-[7px] rotate-45",
                )}
              />
              <span
                className={cn(
                  "block h-px bg-current transition-opacity duration-200",
                  open && "opacity-0",
                )}
              />
              <span
                className={cn(
                  "block h-px bg-current transition-transform duration-300 origin-center",
                  open && "-translate-y-[7px] -rotate-45",
                )}
              />
            </div>
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden border-t border-ink/10 bg-bone animate-mobile-menu">
          <nav className="max-w-[1400px] mx-auto px-6 py-6 flex flex-col gap-4">
            {NAV.map((item, i) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className={cn(
                  "text-lg font-serif transition-colors hover:text-sienna animate-reveal",
                  item.accent ? "text-sienna" : "text-ink",
                )}
                style={{ animationDelay: `${i * 40}ms` }}
              >
                {item.label}
              </Link>
            ))}
            <a
              href={whatsappLink("Salaam! I have an enquiry about Lala Sports.")}
              target="_blank"
              rel="noopener"
              className="mt-2 inline-flex bg-forest text-bone px-4 py-3 text-xs font-bold uppercase tracking-[0.18em]"
            >
              Order via WhatsApp
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
