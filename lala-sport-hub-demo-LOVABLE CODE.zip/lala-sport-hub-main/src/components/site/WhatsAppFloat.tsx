import { whatsappLink } from "@/lib/products";

export function WhatsAppFloat() {
  return (
    <a
      href={whatsappLink("Salaam! I have an enquiry about Lala Sports.")}
      target="_blank"
      rel="noopener"
      aria-label="Chat with Lala Sports on WhatsApp"
      className="fixed bottom-6 right-6 z-50 group flex items-center gap-3 bg-whatsapp text-forest-deep pl-4 pr-5 py-3 shadow-editorial wa-pulse hover:-translate-y-0.5 hover:scale-[1.03] transition-transform"
    >
      <svg
        viewBox="0 0 24 24"
        aria-hidden="true"
        className="w-5 h-5 fill-current transition-transform group-hover:rotate-[8deg]"
      >
        <path d="M17.5 14.4c-.3-.1-1.7-.8-1.9-.9-.3-.1-.5-.1-.7.1-.2.3-.8.9-.9 1.1-.2.2-.3.2-.6.1-.3-.1-1.2-.4-2.4-1.4-.9-.8-1.5-1.7-1.6-2-.2-.3 0-.5.1-.6.1-.1.3-.3.4-.5.1-.2.2-.3.2-.5 0-.2 0-.4-.1-.5-.1-.1-.7-1.6-.9-2.2-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2.1 3.2 5 4.5.7.3 1.3.5 1.7.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 1.9-1.4.2-.7.2-1.2.2-1.4-.1-.1-.3-.2-.6-.3zM12 2C6.5 2 2 6.5 2 12c0 1.9.5 3.7 1.5 5.3L2 22l4.9-1.3c1.5.8 3.3 1.3 5.1 1.3 5.5 0 10-4.5 10-10S17.5 2 12 2z" />
      </svg>
      <span className="text-xs font-bold uppercase tracking-[0.15em]">
        WhatsApp
      </span>
    </a>
  );
}
